/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siciliano;

/**
 *
 * @author user
 */
public class Livro extends Produto {

    public Livro(String nome, String genero, float valor, int quantidade) {
        super(nome, genero, valor, quantidade);
    }
    
//Adaptando o metodo exclusivo para classe Livro
    public void exclusivo(String editora, String autor){
        exclusivo1=editora;
        exclusivo2=autor;
    }
    
    /*public void exclusivo() {
        
    }
    */
    
}
