/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siciliano;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Livraria {
    private ArrayList<Produto> produtos;
    private ArrayList<Produto> controle;
    public Livraria(){
		produtos= new ArrayList<Produto>();
	}
    
    
    
    public void adicionar(Produto p){
        
        produtos.add(p);
    }
    public void remover(String nome){
        
        for(int i=0;i<controle.size();i++){
            if(controle.get(i).nome==nome)
                controle.remove(controle.get(i));
        }
    }
    public ArrayList<Produto> listou(){
        return produtos;
    }
    public void listar(){
        for(int i=0;i<produtos.size();i++){
            System.out.println(produtos.get(i).nome);
        }
    }
    public void Gui(ArrayList<Produto> p){
        controle=p;
    }

}
