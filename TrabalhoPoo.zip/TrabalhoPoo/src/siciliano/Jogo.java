/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siciliano;

/**
 *
 * @author user
 */
public class Jogo extends Produto {
    
    public Jogo(String nome, String genero, float valor,  int quantidade) {
        super(nome, genero, valor, quantidade);
    }
    
    public void exclusivo(String produtora, String plataforma ){
    exclusivo1=produtora;
    exclusivo2=plataforma;

            }
}