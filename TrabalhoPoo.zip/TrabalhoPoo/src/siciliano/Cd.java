/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siciliano;

/**
 *
 * @author user
 */
public class Cd extends Produto {
    
   public Cd(String nome, String genero, float valor,  int quantidade) {
        super(nome, genero, valor,  quantidade);
    }
   public void exclusivo(String banda, String album ){
    exclusivo1=banda;
    exclusivo2=album;

            }
    
}
