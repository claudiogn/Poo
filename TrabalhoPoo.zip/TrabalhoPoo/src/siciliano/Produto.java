/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siciliano;

/**
 *
 * @author user
 */
public abstract class Produto {
    protected String nome;
    protected String genero;
    protected float valor;
    
    protected String exclusivo1;
    protected String exclusivo2;
    protected int quantidade;
    public Produto(String nome, String genero, float valor, int quantidade){
        this.nome=nome;
        this.genero=genero;
        this.valor=valor;
        
        this.quantidade=quantidade;
    }
    
    
    public void exclusivo(String ex1, String ex2){
        exclusivo1=ex1;
        exclusivo2=ex2;
}
        
    

  

//*************************************Metodos get's e set's*****************************************
    public String getNome() {
        return nome;
    }

   
    public void setNome(String nome) {
        this.nome = nome;
    }
      
    public String getGenero() {
        return genero;
    }

    
    public void setGenero(String genero) {
        this.genero = genero;
    }
     
    public float getValor() {
        return valor;
    }

    
    public void setValor(float valor) {
        this.valor = valor;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    

}
